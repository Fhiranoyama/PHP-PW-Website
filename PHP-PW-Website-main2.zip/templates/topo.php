<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website</title>
    <link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
    <header>
        <div class="logo">Serviços Hiranoyama</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="sobre.php">Sobre Nós</a>
            <a href="contato.php">Contato</a>
            <a href="servicos.php">Serviços</a>
			<a href="admin/lista_msg.php">ADMIN</a>
        </nav>
    </header>
</body>
</html>
