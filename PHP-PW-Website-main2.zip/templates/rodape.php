<footer>
    <div class="rodape">
        <p>&copy; 2024 F. Hiranoyama. Todos os direitos reservados.</p>
        <p>Contato: <a href="mailto:fhiranoyama@gmail.com">fhiranoyama@gmail.com</a></p>
    </div>
</footer>