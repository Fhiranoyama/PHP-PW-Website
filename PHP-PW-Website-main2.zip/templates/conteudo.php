<div class="conteudo">
    <h1>F. Hiranoyama Works</h1>
    <p>Esta é a página inicial. Use o menu acima para navegar entre as páginas.</p>
    <p>Aqui você encontrará informações sobre nossos serviços e produtos.</p>

</div>
